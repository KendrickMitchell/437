
#include "Data.h"

double test_point_nn(datapoint input, double* weights, double* vectors, int num_features, int num_internals, int num_weights, int num_vectors, int* results, int num_tests, int ith_test) {
	if (ith_test > num_tests) { return -100; }//Parralel systems should not use the return value of this system.
	double* internals = (double*)malloc(sizeof(double) * num_internals);
	for (int j =0;j<num_internals;j++) {
		internals[j] = 0;
	}

	int i = 0;
	int output = 0;
	int classification = -5;//should be 0 or 1 by the end;
	for (i = 0; i < num_weights; i++) {
		internals[i % num_internals] += input.features[i / num_internals] * weights[i];
	}//Get summations of weights * inputs to internals for each internal

	for (i = 0; i < num_internals; i++) {
		internals[i] = tanh(internals[i]);
	}

	for (i = 0; i < num_vectors; i++) {
		output += internals[i] * vectors[i];
	}

	if (output >= .5) {
		classification = 1;
	}
	else {
		classification = 0;
	}

	results[ith_test] = classification;
	free(internals);
	return classification;
}//tests use a static data structure. good for prarallelizing. 


void fill_internal(double* internals,double* weights, datapoint input, int ith_internal,int num_inputs,int num_internals) {
	for (int i=0;i< num_inputs;i++) {
		internals[ith_internal] += input.features[i] * (weights[(i * num_internals) + ith_internal]);
	}
	internals[ith_internal] = tanh(internals[ith_internal]);
}//Filling each internal separately. Due to no interdependence between internals.

void correct_weights(double* internals, double* weights,double* vectors, datapoint input, double error, int ith_internal, int num_inputs, int num_internals, double alpha) {
	for (int i=0;i<num_inputs;i++) {
		weights[(i * num_internals) + 1] += error * vectors[ith_internal] * (1 - pow(tanh(weights[(i * num_internals) + 1]), 2)) * input.features[i] * alpha;
	}
}//Correct weights grouped on 1 internal node.

//Make a correct_weights and fill_internal based on connections grouped by input feature when there are more internals than input features

void dataset::Execute_nn() {
	//Set up static 6 input. 2 internal, and 1 output model.
	
	//Iterate over all training pieces
	double accuracy = 0;
	double weights[12] = { .5,.5,.5,.5,.5,.5,.5,.5,.5,.5,.5,.5 };
	double internals[2] = { 0,0 };
	double vectors[2] = { .5,.5 };
	double alpha = .00001;
	//Iterate over all training pieces
	int i = 0;
	int j = 0;
	double output = 0.0;
	double error = 0.0;
	double expected = 0.0;//Acceptable and above is 1. Unnacceptable is 0.
	double num_internals = 2, num_weights = 12, num_vectors = 2, num_inputs = 6;
	datapoint input;
	int epochs = 10;
	//Forward propagate to fill internals
//Get output node filled
	printf("\n Training nn parallel. \n");
	clock_t t = clock();
	for (int epoch = 0; epoch < epochs; epoch++) {
		printf("\n Epoch %d \n", epoch);
		for (i = 0; i < this->num_datapoints - this->num_testpoint; i++) {
			input = this->Data[trainindexes[i]];
			output = 0;

			for (j = 0; j < 2; j++) {
				fill_internal(internals, weights, input, j, num_inputs, num_internals);//Truncation is good here
			}//inputs through Weights to internals
			//Forward propagate to fill internals<----1 thread per internal. get a function here.

			for (j = 0; j < 2; j++) {
				output += internals[j] * vectors[j];
			}//internals to vectors leading to output
			if (this->Data[trainindexes[i]].binary_class) { expected = 1.0; }
			else { expected = 0.0; }
			error = output - expected;
			//Get error 

			//Back propagate over weights and correct them based on error and associated interals' activation <-1 process per internal
			for (j = 0; j < 2; j++) {//get a function to correct weights and group by connected internals. group bi input node on othher models 
				correct_weights(internals, weights, vectors, input, error, j, num_inputs, num_internals, alpha);
			}
			
			//Back propagate over vectors and correct them based on error 
			for (j = 0; j < 2; j++) {
				vectors[j] -= error * internals[j] * alpha;
			}
			//Iterate over all test points and use the forward propagation to classify.
		}
	}
	t = clock() - t;
	printf("NN serial training test took me (%f seconds) with %d threads %lf number of internals with %lf features.\n", ((float)t) / CLOCKS_PER_SEC, this->num_threads, num_internals, num_inputs);

	printf("\n NN serial testing \n");
	int* results = (int*)malloc(sizeof(double) * this->num_testpoint);
	t = clock();
	for (i = 0; i < this->num_testpoint; i++) {//test accuracy here
		//printf("test %d\n", i);
		input = this->Data[testindexes[i]];
		test_point_nn(input, weights, vectors, num_inputs, num_internals, num_weights, num_vectors, results, this->num_testpoint, i);

	}


	for (i = 0; i < this->num_testpoint; i++) {
		if ((input.binary_class == true && results[i] == 1.0) || (input.binary_class == false && results[i] == 0.0)) {
			accuracy++;
		}
	}
	accuracy /= this->num_testpoint;
	t = clock() - t;
	printf("NN serial testing test took me (%f seconds) with %d threads %lf number of internals with %lf features.\n", ((float)t) / CLOCKS_PER_SEC, num_threads, num_internals, num_inputs);

	printf("\nNN serial accuracy is %lf", accuracy);
	free(results);
}



void dataset::Execute_nn_parallel() {
	//Set up static 6 input. 2 internal, and 1 output model.
	std::thread threads[4];

	//Iterate over all training pieces
	double accuracy = 0;
	double weights[12] = { .5,.5,.5,.5,.5,.5,.5,.5,.5,.5,.5,.5 };
	double internals[2] = { 0,0 };
	double vectors[2] = { .5,.5 };
	double alpha = .00001;
	//Iterate over all training pieces
	int i = 0;
	int j = 0;
	double output = 0.0;
	double error = 0.0;
	double expected = 0.0;//Acceptable and above is 1. Unnacceptable is 0.
	double num_internals = 2, num_weights = 12, num_vectors = 2, num_inputs = 6;
	datapoint input;
	int epochs = 10;
	//Forward propagate to fill internals
//Get output node filled
	printf("\n Training nn parallel. \n");
	clock_t t = clock();
	for (int epoch = 0;epoch<epochs;epoch++) {
		printf("\n Epoch %d \n", epoch);
		for (i = 0; i < this->num_datapoints - this->num_testpoint; i++) {
			input = this->Data[trainindexes[i]];
			output = 0;

			for (j = 0; j < 2; j++) {
				threads[j] = std::thread(fill_internal, internals, weights, input, j, num_inputs, num_internals);//Truncation is good here
			}//inputs through Weights to internals
			//Forward propagate to fill internals<----1 thread per internal. get a function here.
			threads[0].join();
			threads[1].join();

			for (j = 0; j < 2; j++) {
				output += internals[j] * vectors[j];
			}//internals to vectors leading to output
			if (this->Data[trainindexes[i]].binary_class) { expected = 1.0; }
			else { expected = 0.0; }
			error = output - expected;
			//Get error 

			//Back propagate over weights and correct them based on error and associated interals' activation <-1 process per internal
			for (j = 0; j < 2; j++) {//get a function to correct weights and group by connected internals. group bi input node on othher models 
				threads[j] = std::thread(correct_weights, internals, weights, vectors, input, error, j, num_inputs, num_internals, alpha);
			}
			threads[0].join();
			threads[1].join();
			//Back propagate over vectors and correct them based on error 
			for (j = 0; j < 2; j++) {
				vectors[j] -= error * internals[j] * alpha;
			}
			//Iterate over all test points and use the forward propagation to classify.
		}
	}
	t = clock() - t;
	printf("NN parallel training test took me (%f seconds) with %d threads %lf number of internals with %lf features.\n", ((float)t) / CLOCKS_PER_SEC, this->num_threads,num_internals,num_inputs);

	printf("\n NN parallel testing \n");
	int* results = (int*)malloc(sizeof(double) * this->num_testpoint);
	t = clock();
	for (i = 0; i < this->num_testpoint; i++) {//test accuracy here
		//printf("test %d\n", i);
		input = this->Data[testindexes[i]];
		threads[i%this->num_threads] = std::thread(test_point_nn,input,weights, vectors, num_inputs,num_internals,num_weights,num_vectors,results,this->num_testpoint,i);

			if ((i + 1) % this->num_threads==0) {
				for (j = 0;j < this->num_threads;j++) {
					threads[j].join();
				}
			}

	}
	
	
	for (i=0;i<this->num_testpoint;i++) {
		if ((input.binary_class == true && results[i]==1.0)||(input.binary_class == false && results[i] == 0.0)) {
			accuracy++;
		}
	}
	accuracy /= this->num_testpoint;
	t = clock() - t;
	printf("NN parallel testing test took me (%f seconds) with %d threads %lf number of internals with %lf features.\n", ((float)t) / CLOCKS_PER_SEC, num_threads, num_internals, num_inputs);

	printf("\nNN parallel accuracy is %lf", accuracy);
	free(results);
}
