// Parallel_Machine_Learning.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
#pragma once

#include "Data.h"



int main()
{
    std::cout << "Hello World!\n";
    double test_equivalence = 0;
    double model_equivalence = 0;

    double train_accuracy = 0, test_accuracy = 0;
    time_t start, end;

    dataset proj;
    proj.allocate_data(1727);
    proj.file_read();//Maybe a huge buffer is alright.
    proj.set_data_indices();
    printf("\nNow executing learning\n");
    //proj.Execute_knn
    //proj.Execute_perceptron
    //Get data into buffer.
    //Parse buffer to fill out data features.  Do in serial. Maybe in parralel later
}
//The project will be implementing several machine learning models and seeing how feasible and beneficial doing so is.
//Feasibility is based on how trivial or difficult it is to implement. 
//Benefit is the time improvement of parallelization and the equivelance of the parallel model to its serial counterpart
//I was encouraged to start with knn and compare supervised to supervised and unsupervised to unsupervised.
//Keep in mind which models can train in parallel all models should be able to test in parralel.
//Classification will most likely be used for all models.

//The data is car data and classified as whether a car is acceptable or not. 
//The features are cost, maintenance cost, doors, capacity, luggage space, and saftey.
//only doors and capacity are numberic but they are discrete integers. So categorical and numerical values can easily be 
//transformed. Classification is binary too. 